import Img1 from "../assets/pics/1.jpeg";
import Img2 from "../assets/pics/2.jpeg";
import Img3 from "../assets/pics/3.jpeg";
import Img4 from "../assets/pics/4.jpeg";
import Img5 from "../assets/pics/5.jpeg";
import Img6 from "../assets/pics/6.jpeg";
import Img7 from "../assets/pics/8.jpeg";
import Img8 from "../assets/pics/7.jpeg";
import Img9 from "../assets/pics/10.jpeg";
import Img10 from "../assets/pics/11.jpeg";
import Img11 from "../assets/pics/12.jpeg";
import Img12 from "../assets/pics/13.jpeg";

export const images = [
  {
    src: Img1,
  },
  {
    src: Img2,
  },
  {
    src: Img3,
  },
  {
    src: Img4,
  },
  {
    src: Img5,
  },
  {
    src: Img6,
  },
  {
    src: Img7,
  },
  {
    src: Img8,
  },
  {
    src: Img9,
  },
  {
    src: Img10,
  },
  {
    src: Img11,
  },
  {
    src: Img12,
  },
];
